<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Function with parameters</title>
</head>
<body>
    <h2>php with two parameters</h2>
    <?php
     function addfunction($num1,$num2) {
        $sum = $num1 + $num2;
        echo "Sum of the two numbers is : $sum";
     }

     addfunction(10,20);
     ?>
</body>
</html>