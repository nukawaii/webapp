<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Function</title>
</head>
<body>
    <h2>This is first time for PHP</h2>
    <?php
    /* Defining aPHP Function */
    function writeMessage() {
        echo "You are really a nice person, Have a nice time!";
    }

    /* Calling a PHP Function */
    writeMessage();
    ?>
</body>
</html>