<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Function with Passing Argument by Reference</title>
</head>
<body>
<?php
    function printMe($param = NULL) {
        print $param;
    }
    printMe("This is Test");
    printMe();
    printMe("<br />This is Test");
    printMe();printMe();
    ?>
</body>
</html>
 
 